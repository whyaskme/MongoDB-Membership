<!-- Please refer to our contributing documentation for any questions on submitting a pull request, or let us know here if you need any help: [CONTRIBUTING](https://github.com/matteofabbri/AspNetCore.Identity.Mongo/blob/master/CONTRIBUTING.md) -->

What does this implement/fix? Explain your changes.
---------------------------------------------------
…

Does this close any currently open issues?
------------------------------------------
Mention issue using [basic-writing-and-formatting-syntax#referencing-issues-and-pull-requests](https://docs.github.com/en/github/writing-on-github/basic-writing-and-formatting-syntax#referencing-issues-and-pull-requests)


Any relevant logs, error output, etc?
-------------------------------------
(If it’s long, please paste to https://ghostbin.com/ and insert the link here.)

Where has this been tested?
---------------------------
**Operating System:** …

**.Net Core Verion:** …

Does this introduce a breaking change?
-----------------------------------------
<!--  (check one with "x") -->
- [ ] Yes
- [ ] No

Any other comments?
-------------------
…
